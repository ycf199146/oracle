$Header: 215187.1 0_mon_readme.txt 11.4.5.8 2013/05/10 carlos.sierra $

Requires Oracle Tuning Pack license.

1. Open a new session and execute 1_mon_repository.sql followed by 2_mon_capture.sql.
   The latter will loop indefinitely.
2. On a second session execute 3_mon_reports.sql every so often.
3. When ready to review unzip mon_reports.zip into a directory and browse mon_main.html.
